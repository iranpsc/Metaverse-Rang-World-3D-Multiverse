using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Network_A.Auth;
using UnityEngine;
using UnityEngine.Networking;

namespace Network_A.DedicatedGameServer.Client
{
    public class DedicatedGameTicketClient : MonoBehaviour
    {
        [Header("Node Game Server Control")]
        [SerializeField] private string controlBaseUrl = "https://dev-world-3d.metarang.com";

        [Header("Ticket Request")]
        [SerializeField] private string roomId = "room_vps_test_001";
        [SerializeField] private string region = "eu-central";
        [SerializeField] private string zone = "de-1";
        [SerializeField] private string preferredServerId = "ds_vps_test_001";
        [SerializeField] private int minFreeSlots = 1;
        [SerializeField] private int ticketTtlSeconds = 60;

        [Header("Http")]
        [SerializeField] private int timeoutSeconds = 15;
        [SerializeField] private bool logRawResponse = true;

        public DedicatedGameTicketResponseDto LastResponse { get; private set; }
        public string LastError { get; private set; }
        public string LastRawBody { get; private set; }

        //* این تابع از اینسپکتور برای گرفتن دستی گیم تیکت استفاده می شود.
        [ContextMenu("Request Game Ticket")]
        public async void Btn_RequestGameTicket()
        {
            await RequestGameTicketAsync();
        }

        //* این تابع با اکسس توکن ذخیره شده، از نود جی اس گیم تیکت می گیرد.
        public async Task<DedicatedGameTicketResponseDto> RequestGameTicketAsync(CancellationToken cancellationToken = default)
        {
            LastResponse = null;
            LastError = string.Empty;
            LastRawBody = string.Empty;

            string accessToken = SecureTokenStorage.GetAccessToken();

            if (string.IsNullOrWhiteSpace(accessToken))
            {
                LastError = "access_token_missing";
                Debug.LogError("[DedicatedGameTicketClient] Access token is missing. Login must complete before requesting game ticket.");
                return null;
            }

            DedicatedGameTicketRequestDto requestDto = new DedicatedGameTicketRequestDto
            {
                roomId = SafeTrim(roomId),
                region = SafeTrim(region),
                zone = SafeTrim(zone),
                preferredServerId = SafeTrim(preferredServerId),
                minFreeSlots = Mathf.Max(1, minFreeSlots),
                ticketTtlSeconds = Mathf.Clamp(ticketTtlSeconds, 5, 3600),
                metadata = new DedicatedGameTicketRequestMetadataDto
                {
                    source = "unity_client",
                    platform = Application.platform.ToString(),
                    unityVersion = Application.unityVersion,
                    client = "DedicatedGameTicketClient"
                }
            };

            if (string.IsNullOrWhiteSpace(requestDto.roomId))
            {
                LastError = "room_id_empty";
                Debug.LogError("[DedicatedGameTicketClient] Room id is empty.");
                return null;
            }

            string url = BuildControlUrl("/game-server-control/client/ticket");
            string json = JsonUtility.ToJson(requestDto);

            DedicatedTicketHttpResult httpResult = await SendJsonPostAsync(url, json, accessToken, cancellationToken);

            LastRawBody = httpResult.RawBody;

            if (!httpResult.IsSuccess)
            {
                LastError = httpResult.ErrorMessage;
                Debug.LogError("[DedicatedGameTicketClient] Ticket request failed | " + httpResult.ErrorMessage);
                return null;
            }

            DedicatedGameTicketResponseDto response = ParseResponse(httpResult.RawBody);

            if (response == null)
            {
                LastError = "ticket_response_parse_failed";
                Debug.LogError("[DedicatedGameTicketClient] Ticket response parse failed.");
                return null;
            }

            if (!response.success)
            {
                LastError = response.reason + " | " + response.message;
                Debug.LogError("[DedicatedGameTicketClient] Ticket request rejected | reason=" + response.reason + " | message=" + response.message);
                return response;
            }

            if (!ValidateTicketResponse(response, out string validationError))
            {
                LastError = validationError;
                Debug.LogError("[DedicatedGameTicketClient] Ticket response invalid | " + validationError);
                return response;
            }

            LastResponse = response;
            LastError = string.Empty;

            Debug.Log("[DedicatedGameTicketClient] Ticket ok | ticketId=" +
                      response.data.ticket.ticketId +
                      " | serverId=" + response.data.connection.serverId +
                      " | roomId=" + response.data.connection.roomId +
                      " | host=" + response.data.connection.host +
                      " | port=" + response.data.connection.port);

            return response;
        }

        //* این تابع بررسی می کند پاسخ تیکت برای اتصال به ددیکیتد سرور کافی است یا نه.
        private bool ValidateTicketResponse(DedicatedGameTicketResponseDto response, out string error)
        {
            if (response == null || response.data == null)
            {
                error = "ticket_response_data_missing";
                return false;
            }

            if (response.data.ticket == null)
            {
                error = "ticket_missing";
                return false;
            }

            if (response.data.connection == null)
            {
                error = "connection_missing";
                return false;
            }

            if (string.IsNullOrWhiteSpace(response.data.ticket.ticketId))
            {
                error = "ticket_id_missing";
                return false;
            }

            if (string.IsNullOrWhiteSpace(response.data.ticket.signature))
            {
                error = "ticket_signature_missing";
                return false;
            }

            if (string.IsNullOrWhiteSpace(response.data.userId))
            {
                error = "ticket_user_id_missing";
                return false;
            }

            if (string.IsNullOrWhiteSpace(response.data.connection.roomId))
            {
                error = "connection_room_id_missing";
                return false;
            }

            if (string.IsNullOrWhiteSpace(response.data.connection.serverId))
            {
                error = "connection_server_id_missing";
                return false;
            }

            if (string.IsNullOrWhiteSpace(response.data.connection.sessionId))
            {
                error = "connection_session_id_missing";
                return false;
            }

            if (string.IsNullOrWhiteSpace(response.data.connection.host))
            {
                error = "connection_host_missing";
                return false;
            }

            if (response.data.connection.port <= 0)
            {
                error = "connection_port_invalid";
                return false;
            }

            error = string.Empty;
            return true;
        }

        //* این تابع درخواست جیسون پست را با Authorization Bearer ارسال می کند.
        private async Task<DedicatedTicketHttpResult> SendJsonPostAsync(
            string url,
            string json,
            string accessToken,
            CancellationToken cancellationToken)
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);

            using (UnityWebRequest request = new UnityWebRequest(url, UnityWebRequest.kHttpVerbPOST))
            {
                request.uploadHandler = new UploadHandlerRaw(bodyRaw);
                request.downloadHandler = new DownloadHandlerBuffer();
                request.timeout = Mathf.Max(1, timeoutSeconds);

                request.SetRequestHeader("Content-Type", "application/json");
                request.SetRequestHeader("Accept", "application/json");
                request.SetRequestHeader("Authorization", "Bearer " + accessToken.Trim());
                request.SetRequestHeader("X-Metaverse-Client", "unity");

                UnityWebRequestAsyncOperation operation = request.SendWebRequest();

                while (!operation.isDone)
                {
                    if (cancellationToken.IsCancellationRequested)
                    {
                        request.Abort();
                        return DedicatedTicketHttpResult.Fail(0, "request_cancelled", string.Empty);
                    }

                    await Task.Yield();
                }

                string rawBody = request.downloadHandler != null ? request.downloadHandler.text : string.Empty;
                int statusCode = (int)request.responseCode;

                if (logRawResponse)
                {
                    Debug.Log("[DedicatedGameTicketClient] Status=" + statusCode + " Body=" + rawBody);
                }

                bool isHttpOk = statusCode >= 200 && statusCode < 300;
                bool hasTransportError =
                    request.result == UnityWebRequest.Result.ConnectionError ||
                    request.result == UnityWebRequest.Result.DataProcessingError;

                if (!isHttpOk || hasTransportError)
                {
                    string error = string.IsNullOrWhiteSpace(request.error) ? rawBody : request.error;
                    return DedicatedTicketHttpResult.Fail(statusCode, error, rawBody);
                }

                return DedicatedTicketHttpResult.Success(statusCode, rawBody);
            }
        }

        //* این تابع پاسخ جیسون گیم تیکت را می خواند.
        private DedicatedGameTicketResponseDto ParseResponse(string rawBody)
        {
            if (string.IsNullOrWhiteSpace(rawBody)) return null;

            try
            {
                return JsonUtility.FromJson<DedicatedGameTicketResponseDto>(rawBody);
            }
            catch (Exception ex)
            {
                Debug.LogError("[DedicatedGameTicketClient] Parse exception | " + ex.Message);
                return null;
            }
        }

        //* این تابع آدرس کامل گیم سرور کنترل را می سازد.
        private string BuildControlUrl(string path)
        {
            string safeBase = SafeTrim(controlBaseUrl).TrimEnd('/');
            string safePath = SafeTrim(path);

            if (!safePath.StartsWith("/")) safePath = "/" + safePath;

            return safeBase + safePath;
        }

        //* این تابع مقدار رشته را بدون نال و فاصله اضافه برمی گرداند.
        private string SafeTrim(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }

        /*
        توضیح مکتوب فایل:
        این اسکریپت سمت کلاینت، گیم تیکت را به صورت خودکار از نود جی اس می گیرد.
        اکسس توکن را از SecureTokenStorage می خواند و با هدر Authorization ارسال می کند.
        یوزر آی دی از بادی ارسال نمی شود، چون سرور باید آن را از اکسس توکن معتبر استخراج کند.
        خروجی این فایل شامل ticketId، signature و اطلاعات connection است.
        مرحله بعد DedicatedGameServerAutoConnectController همین تیکت را به DedicatedGameServerWsClient می دهد.
        */
    }

    [Serializable]
    public class DedicatedGameTicketRequestDto
    {
        public string roomId;
        public string region;
        public string zone;
        public string preferredServerId;
        public int minFreeSlots;
        public int ticketTtlSeconds;
        public DedicatedGameTicketRequestMetadataDto metadata;
    }

    [Serializable]
    public class DedicatedGameTicketRequestMetadataDto
    {
        public string source;
        public string platform;
        public string unityVersion;
        public string client;
    }

    [Serializable]
    public class DedicatedGameTicketResponseDto
    {
        public bool success;
        public string reason;
        public string message;
        public DedicatedGameTicketResponseDataDto data;
        public long ts;
    }

    [Serializable]
    public class DedicatedGameTicketResponseDataDto
    {
        public string userId;
        public DedicatedGameTicketDto ticket;
        public DedicatedGameTicketConnectionDto connection;
        public DedicatedGameTicketSessionDto session;
    }

    [Serializable]
    public class DedicatedGameTicketDto
    {
        public string ticketId;
        public string userId;
        public string roomId;
        public string serverId;
        public long expiresAt;
        public string signature;
    }

    [Serializable]
    public class DedicatedGameTicketConnectionDto
    {
        public string serverId;
        public string host;
        public int port;
        public string roomId;
        public string sessionId;
        public string region;
        public string zone;
    }

    [Serializable]
    public class DedicatedGameTicketSessionDto
    {
        public string sessionId;
        public string roomId;
        public string serverId;
        public string status;
        public int maxPlayers;
        public int currentPlayers;
        public string region;
        public string zone;
    }

    public class DedicatedTicketHttpResult
    {
        public bool IsSuccess { get; private set; }
        public int StatusCode { get; private set; }
        public string ErrorMessage { get; private set; }
        public string RawBody { get; private set; }

        //* این تابع نتیجه موفق اچ تی تی پی را می سازد.
        public static DedicatedTicketHttpResult Success(int statusCode, string rawBody)
        {
            return new DedicatedTicketHttpResult
            {
                IsSuccess = true,
                StatusCode = statusCode,
                ErrorMessage = string.Empty,
                RawBody = rawBody
            };
        }

        //* این تابع نتیجه ناموفق اچ تی تی پی را می سازد.
        public static DedicatedTicketHttpResult Fail(int statusCode, string errorMessage, string rawBody)
        {
            return new DedicatedTicketHttpResult
            {
                IsSuccess = false,
                StatusCode = statusCode,
                ErrorMessage = errorMessage,
                RawBody = rawBody
            };
        }
    }
}
