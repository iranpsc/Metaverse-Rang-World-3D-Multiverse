using System;
using System.Threading;
using System.Threading.Tasks;
using Network_A.GameServer.Players;
using UnityEngine;

namespace Network_A.GameServer
{
    public class DedicatedHeartbeatLoop : MonoBehaviour
    {
        [Header("Runtime")]
        [SerializeField] private DedicatedServerRuntime runtime;
        [SerializeField] private GameServerControlDedicatedClient controlClient;
        [SerializeField] private DedicatedPlayerRegistry playerRegistry;

        [Header("Loop")]
        [SerializeField] private bool autoStartOnRuntimeStarted = true;
        [SerializeField] private bool registerBeforeHeartbeat = true;
        [SerializeField] private int currentPlayersForTest = 0;
        [SerializeField] private bool usePlayerRegistryCount = true;

        private CancellationTokenSource heartbeatCts;
        private bool isLoopRunning;

        //* این تابع رفرنس های لازم را در شروع آبجکت پیدا می کند.
        private void Awake()
        {
            EnsureReferences();
        }

        //* این تابع هنگام فعال شدن آبجکت، رویداد شروع و توقف ران تایم را گوش می دهد.
        private void OnEnable()
        {
            EnsureReferences();

            if (runtime != null)
            {
                runtime.RuntimeStarted += HandleRuntimeStarted;
                runtime.RuntimeStopped += HandleRuntimeStopped;
            }
        }

        //* این تابع هنگام غیرفعال شدن آبجکت، رویدادها را پاک و حلقه هارت بیت را متوقف می کند.
        private void OnDisable()
        {
            if (runtime != null)
            {
                runtime.RuntimeStarted -= HandleRuntimeStarted;
                runtime.RuntimeStopped -= HandleRuntimeStopped;
            }

            StopHeartbeatLoop();
        }

        //* این تابع رفرنس های ران تایم، کلاینت کنترل و رجیستری پلیر را از همین آبجکت پیدا می کند.
        private void EnsureReferences()
        {
            if (runtime == null)
            {
                runtime = GetComponent<DedicatedServerRuntime>();
                if (runtime == null) runtime = DedicatedServerRuntime.Instance;
            }

            if (controlClient == null)
            {
                controlClient = GetComponent<GameServerControlDedicatedClient>();
            }

            if (playerRegistry == null)
            {
                playerRegistry = GetComponent<DedicatedPlayerRegistry>();
            }
        }

        //* این تابع بعد از شروع ران تایم، حلقه هارت بیت را شروع می کند.
        private void HandleRuntimeStarted(DedicatedServerConfigData config)
        {
            if (!autoStartOnRuntimeStarted) return;

            StartHeartbeatLoop();
        }

        //* این تابع بعد از توقف ران تایم، حلقه هارت بیت را متوقف می کند.
        private void HandleRuntimeStopped()
        {
            StopHeartbeatLoop();
        }

        //* این تابع از اینسپکتور برای شروع دستی حلقه هارت بیت استفاده می شود.
        [ContextMenu("Start Heartbeat Loop")]
        public void StartHeartbeatLoop()
        {
            if (isLoopRunning)
            {
                Debug.Log("[DedicatedHeartbeatLoop] Heartbeat loop is already running.");
                return;
            }

            EnsureReferences();

            if (runtime == null)
            {
                Debug.LogError("[DedicatedHeartbeatLoop] Runtime is missing.");
                return;
            }

            if (controlClient == null)
            {
                Debug.LogError("[DedicatedHeartbeatLoop] GameServerControlDedicatedClient is missing.");
                return;
            }

            DedicatedServerConfigData config = runtime.GetCurrentConfig();

            if (config == null)
            {
                Debug.LogError("[DedicatedHeartbeatLoop] Runtime config is missing.");
                return;
            }

            heartbeatCts = new CancellationTokenSource();
            isLoopRunning = true;

            Debug.Log("[DedicatedHeartbeatLoop] Heartbeat loop started.");
            RunHeartbeatLoopAsync(config, heartbeatCts.Token);
        }

        //* این تابع از اینسپکتور یا کد برای توقف دستی حلقه هارت بیت استفاده می شود.
        [ContextMenu("Stop Heartbeat Loop")]
        public void StopHeartbeatLoop()
        {
            if (!isLoopRunning) return;

            isLoopRunning = false;

            if (heartbeatCts != null)
            {
                heartbeatCts.Cancel();
                heartbeatCts.Dispose();
                heartbeatCts = null;
            }

            Debug.Log("[DedicatedHeartbeatLoop] Heartbeat loop stopped.");
        }

        //* این تابع حلقه اصلی رجیستر و هارت بیت را اجرا می کند.
        private async void RunHeartbeatLoopAsync(DedicatedServerConfigData config, CancellationToken cancellationToken)
        {
            try
            {
                if (registerBeforeHeartbeat)
                {
                    bool registerOk = await controlClient.RegisterCurrentRuntimeAsync(cancellationToken);

                    if (!registerOk)
                    {
                        Debug.LogError("[DedicatedHeartbeatLoop] Register before heartbeat failed.");
                    }
                }

                while (!cancellationToken.IsCancellationRequested && runtime != null && runtime.IsRunning)
                {
                    int currentPlayers = ReadCurrentPlayers();
                    await controlClient.SendHeartbeatAsync(currentPlayers, cancellationToken);
                    await DelaySeconds(config.heartbeatIntervalSeconds, cancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                Debug.Log("[DedicatedHeartbeatLoop] Heartbeat loop cancelled.");
            }
            catch (Exception ex)
            {
                Debug.LogError("[DedicatedHeartbeatLoop] Heartbeat loop error | " + ex.Message);
            }
            finally
            {
                isLoopRunning = false;
            }
        }

        //* این تابع تعداد پلیرهای فعلی را از رجیستری یا مقدار تستی می خواند.
        private int ReadCurrentPlayers()
        {
            EnsureReferences();

            if (usePlayerRegistryCount && playerRegistry != null)
            {
                return Mathf.Max(0, playerRegistry.GetCurrentPlayerCount());
            }

            return Mathf.Max(0, currentPlayersForTest);
        }

        //* این تابع تاخیر قابل کنسل برای فاصله بین هارت بیت ها می سازد.
        private async Task DelaySeconds(float seconds, CancellationToken cancellationToken)
        {
            float safeSeconds = Mathf.Max(1f, seconds);
            int milliseconds = Mathf.RoundToInt(safeSeconds * 1000f);

            await Task.Delay(milliseconds, cancellationToken);
        }

        //* این تابع هنگام حذف آبجکت، حلقه هارت بیت را تمیز متوقف می کند.
        private void OnDestroy()
        {
            StopHeartbeatLoop();
        }

        /*
        توضیح مکتوب فایل:
        این اسکریپت حلقه دائمی هارت بیت ددیکیتد سرور را مدیریت می کند.
        وقتی DedicatedServerRuntime شروع شد، ابتدا در صورت نیاز رجیستر انجام می شود.
        سپس در فاصله مشخص شده داخل کانفیگ، هارت بیت به نود جی اس ارسال می شود.
        در این نسخه، اگر DedicatedPlayerRegistry وصل باشد، تعداد واقعی پلیرها به نود جی اس فرستاده می شود.
        اگر رجیستری وصل نباشد، مقدار currentPlayersForTest استفاده می شود.
        */
    }
}
