using System;
using UnityEngine;

namespace Network_A.GameServer
{
    public class DedicatedServerRuntime : MonoBehaviour
    {
        public static DedicatedServerRuntime Instance { get; private set; }

        [Header("Config")]
        [SerializeField] private DedicatedServerConfig config;

        public bool IsRunning { get; private set; }
        public DedicatedServerConfigData CurrentConfig { get; private set; }

        public event Action<DedicatedServerConfigData> RuntimeStarted;
        public event Action RuntimeStopped;
        public event Action<string> RuntimeFailed;

        //* این تابع سینگلتون ساده ران تایم ددیکیتد سرور را آماده می کند.
        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                EnsureConfigReference();
                return;
            }

            Destroy(gameObject);
        }

        //* این تابع در شروع صحنه بررسی می کند که ددیکیتد سرور باید خودکار شروع شود یا نه.
        private void Start()
        {
            EnsureConfigReference();

            if (config == null)
            {
                FailRuntime("DedicatedServerConfig not found.");
                return;
            }

            DedicatedServerConfigData snapshot = config.CreateSnapshot();

            if (snapshot.autoStart)
            {
                StartDedicatedRuntime();
            }
            else
            {
                Log("Auto start is disabled.");
            }
        }

        //* این تابع رفرنس کانفیگ را از همین آبجکت یا فرزندان آن پیدا می کند.
        private void EnsureConfigReference()
        {
            if (config != null) return;

            config = GetComponent<DedicatedServerConfig>();
            if (config != null) return;

            config = GetComponentInChildren<DedicatedServerConfig>(true);
        }

        //* این تابع از اینسپکتور یا دکمه تست برای شروع ران تایم ددیکیتد سرور استفاده می شود.
        [ContextMenu("Start Dedicated Runtime")]
        public void StartDedicatedRuntime()
        {
            if (IsRunning)
            {
                Log("Dedicated runtime is already running.");
                return;
            }

            EnsureConfigReference();

            if (config == null)
            {
                FailRuntime("DedicatedServerConfig is missing.");
                return;
            }

            if (!config.ValidateForRuntime(out string error))
            {
                FailRuntime(error);
                return;
            }

            CurrentConfig = config.CreateSnapshot();
            IsRunning = true;

            Log("Dedicated runtime started.");
            Log(config.ToDebugText());

            RuntimeStarted?.Invoke(CurrentConfig);
        }

        //* این تابع از اینسپکتور یا کد برای توقف ران تایم ددیکیتد سرور استفاده می شود.
        [ContextMenu("Stop Dedicated Runtime")]
        public void StopDedicatedRuntime()
        {
            if (!IsRunning)
            {
                Log("Dedicated runtime is already stopped.");
                return;
            }

            IsRunning = false;

            Log("Dedicated runtime stopped.");
            RuntimeStopped?.Invoke();
        }

        //* این تابع آخرین کانفیگ معتبر ران تایم را برمی گرداند.
        public DedicatedServerConfigData GetCurrentConfig()
        {
            if (CurrentConfig != null) return CurrentConfig;
            if (config == null) EnsureConfigReference();

            return config != null ? config.CreateSnapshot() : null;
        }

        //* این تابع مشخص می کند که ران تایم برای تست ویندوز ادیتور فعال است یا نه.
        public bool IsWindowsEditorTestRuntime()
        {
            DedicatedServerConfigData snapshot = GetCurrentConfig();
            return snapshot != null && snapshot.runMode == DedicatedServerRunMode.WindowsEditorTest;
        }

        //* این تابع مشخص می کند که ران تایم برای بیلد لینوکس هدلس فعال است یا نه.
        public bool IsLinuxHeadlessRuntime()
        {
            DedicatedServerConfigData snapshot = GetCurrentConfig();
            return snapshot != null && snapshot.runMode == DedicatedServerRunMode.LinuxHeadlessServer;
        }

        //* این تابع خطای شروع یا اجرای ران تایم را لاگ می کند و به شنونده ها خبر می دهد.
        private void FailRuntime(string error)
        {
            IsRunning = false;
            CurrentConfig = null;

            Debug.LogError("[DedicatedServerRuntime] Failed | " + error);
            RuntimeFailed?.Invoke(error);
        }

        //* این تابع لاگ های معمولی ددیکیتد سرور را در کنسول یونیتی چاپ می کند.
        private void Log(string message)
        {
            DedicatedServerConfigData snapshot = CurrentConfig ?? config?.CreateSnapshot();

            if (snapshot != null && !snapshot.verboseLogs) return;

            Debug.Log("[DedicatedServerRuntime] " + message);
        }

        //* این تابع هنگام خروج یا حذف آبجکت، ران تایم را تمیز متوقف می کند.
        private void OnDestroy()
        {
            if (Instance == this)
            {
                if (IsRunning) StopDedicatedRuntime();
                Instance = null;
            }
        }

        /*
        توضیح مکتوب فایل:
        این اسکریپت نقطه شروع ددیکیتد سرور یونیتی است.
        در این فاز فقط کانفیگ را می خواند، اعتبارسنجی می کند و وضعیت ران تایم را فعال می کند.
        هنوز رجیستر، هارت بیت، لیسنر وب سوکت و وریفای تیکت داخل این فایل وجود ندارد.
        فازهای بعدی با گوش دادن به رویداد RuntimeStarted به این ران تایم وصل می شوند.
        این فایل باید روی همان آبجکتی باشد که DedicatedServerConfig روی آن قرار دارد.
        */
    }
}
