using System;
using UnityEngine;

namespace Network_A.GameServer
{
    public enum DedicatedServerRunMode
    {
        Disabled = 0,
        WindowsEditorTest = 1,
        LinuxHeadlessServer = 2
    }

    [Serializable]
    public class DedicatedServerConfigData
    {
        public DedicatedServerRunMode runMode;
        public string controlBaseUrl;
        public string serverId;
        public string publicHost;
        public int publicPort;
        public string listenHost;
        public int listenPort;
        public string roomId;
        public string region;
        public string zone;
        public int maxPlayers;
        public int tickRate;
        public string buildVersion;
        public string serviceToken;
        public float heartbeatIntervalSeconds;
        public bool autoStart;
        public bool verboseLogs;
    }

    public class DedicatedServerConfig : MonoBehaviour
    {
        [Header("Run Mode")]
        [SerializeField] private DedicatedServerRunMode runMode = DedicatedServerRunMode.WindowsEditorTest;
        [SerializeField] private bool autoStart = false;
        [SerializeField] private bool verboseLogs = true;

        [Header("Node Game Server Control")]
        [SerializeField] private string controlBaseUrl = "https://dev-world-3d.metarang.com";
        [SerializeField] private string serviceToken = "";

        [Header("Dedicated Identity")]
        [SerializeField] private string serverId = "ds_vps_test_001";
        [SerializeField] private string roomId = "room_vps_test_001";
        [SerializeField] private string region = "eu-central";
        [SerializeField] private string zone = "de-1";

        [Header("Public Connection")]
        [SerializeField] private string publicHost = "127.0.0.1";
        [SerializeField] private int publicPort = 7777;

        [Header("Local Listener")]
        [SerializeField] private string listenHost = "127.0.0.1";
        [SerializeField] private int listenPort = 7777;

        [Header("Capacity")]
        [SerializeField] private int maxPlayers = 20;
        [SerializeField] private int tickRate = 20;
        [SerializeField] private float heartbeatIntervalSeconds = 5f;

        [Header("Build")]
        [SerializeField] private string buildVersion = "windows-editor-test";

        //* این تابع نسخه خواندنی کانفیگ ددیکیتد سرور را برای بقیه اسکریپت ها می سازد.
        public DedicatedServerConfigData CreateSnapshot()
        {
            return new DedicatedServerConfigData
            {
                runMode = runMode,
                controlBaseUrl = SafeTrim(controlBaseUrl),
                serverId = SafeTrim(serverId),
                publicHost = SafeTrim(publicHost),
                publicPort = Mathf.Max(1, publicPort),
                listenHost = SafeTrim(listenHost),
                listenPort = Mathf.Max(1, listenPort),
                roomId = SafeTrim(roomId),
                region = SafeTrim(region),
                zone = SafeTrim(zone),
                maxPlayers = Mathf.Max(1, maxPlayers),
                tickRate = Mathf.Max(1, tickRate),
                buildVersion = SafeTrim(buildVersion),
                serviceToken = SafeTrim(serviceToken),
                heartbeatIntervalSeconds = Mathf.Max(1f, heartbeatIntervalSeconds),
                autoStart = autoStart,
                verboseLogs = verboseLogs
            };
        }

        //* این تابع مشخص می کند که ددیکیتد سرور اجازه شروع شدن دارد یا نه.
        public bool CanRunDedicatedServer()
        {
            return runMode != DedicatedServerRunMode.Disabled;
        }

        //* این تابع مشخص می کند که حالت فعلی برای تست داخل ویندوز ادیتور است یا نه.
        public bool IsWindowsEditorTest()
        {
            return runMode == DedicatedServerRunMode.WindowsEditorTest;
        }

        //* این تابع مشخص می کند که حالت فعلی برای بیلد لینوکس هدلس است یا نه.
        public bool IsLinuxHeadlessServer()
        {
            return runMode == DedicatedServerRunMode.LinuxHeadlessServer;
        }

        //* این تابع آدرس رجیستر را از بیس یو آر ال نود جی اس می سازد.
        public string GetRegisterUrl()
        {
            return BuildControlUrl("/game-server-control/dedicated/register");
        }

        //* این تابع آدرس هارت بیت را از بیس یو آر ال نود جی اس می سازد.
        public string GetHeartbeatUrl()
        {
            return BuildControlUrl("/game-server-control/dedicated/heartbeat");
        }

        //* این تابع آدرس وریفای تیکت را از بیس یو آر ال نود جی اس می سازد.
        public string GetVerifyTicketUrl()
        {
            return BuildControlUrl("/game-server-control/dedicated/verify-ticket");
        }

        //* این تابع آدرس کامل مسیرهای گیم سرور کنترل را با حذف اسلش اضافه می سازد.
        public string BuildControlUrl(string path)
        {
            string safeBase = SafeTrim(controlBaseUrl).TrimEnd('/');
            string safePath = SafeTrim(path);

            if (!safePath.StartsWith("/")) safePath = "/" + safePath;

            return safeBase + safePath;
        }

        //* این تابع کانفیگ را برای شروع فازهای بعدی اعتبارسنجی می کند.
        public bool ValidateForRuntime(out string error)
        {
            DedicatedServerConfigData snapshot = CreateSnapshot();

            if (snapshot.runMode == DedicatedServerRunMode.Disabled)
            {
                error = "Dedicated server run mode is disabled.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(snapshot.controlBaseUrl))
            {
                error = "Control base url is empty.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(snapshot.serverId))
            {
                error = "Server id is empty.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(snapshot.roomId))
            {
                error = "Room id is empty.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(snapshot.region))
            {
                error = "Region is empty.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(snapshot.zone))
            {
                error = "Zone is empty.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(snapshot.publicHost))
            {
                error = "Public host is empty.";
                return false;
            }

            if (snapshot.publicPort <= 0)
            {
                error = "Public port is invalid.";
                return false;
            }

            if (snapshot.listenPort <= 0)
            {
                error = "Listen port is invalid.";
                return false;
            }

            error = string.Empty;
            return true;
        }

        //* این تابع خلاصه کانفیگ را برای دیباگ داخل کنسول یونیتی آماده می کند.
        public string ToDebugText()
        {
            DedicatedServerConfigData snapshot = CreateSnapshot();

            return "DedicatedServerConfig" +
                   " | runMode=" + snapshot.runMode +
                   " | serverId=" + snapshot.serverId +
                   " | public=" + snapshot.publicHost + ":" + snapshot.publicPort +
                   " | listen=" + snapshot.listenHost + ":" + snapshot.listenPort +
                   " | roomId=" + snapshot.roomId +
                   " | region=" + snapshot.region +
                   " | zone=" + snapshot.zone +
                   " | maxPlayers=" + snapshot.maxPlayers +
                   " | tickRate=" + snapshot.tickRate +
                   " | autoStart=" + snapshot.autoStart;
        }

        //* این تابع مقدار رشته را بدون نال و فاصله اضافه برمی گرداند.
        private string SafeTrim(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }

        /*
        توضیح مکتوب فایل:
        این اسکریپت کانفیگ پایه ددیکیتد سرور یونیتی را نگه می دارد.
        این فایل هنوز سرور وب سوکت را اجرا نمی کند و هنوز به نود جی اس رجیستر نمی زند.
        وظیفه این فایل فقط آماده کردن شناسه سرور، روم، ریجن، زون، هاست، پورت و ظرفیت است.
        در فاز بعدی همین داده ها برای رجیستر و هارت بیت به گیم سرور کنترل استفاده می شوند.
        این اسکریپت باید فقط روی آبجکت مخصوص ددیکیتد سرور قرار بگیرد.
        */
    }
}
