using System;
using System.Collections;
using System.Threading.Tasks;
using Network_A.GameServer;
using Network_A.DedicatedGameServer.Bootstrap;
using UnityEngine;
using UnityEngine.UI;

#if UNITY_EDITOR
using UnityEditor;
#endif

#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
using Network_A.Core;
#endif

public class ExitGameButton : MonoBehaviour
{
        [Header("Button")]
        [SerializeField] private Button btnExit;

        [Header("Dedicated Shutdown")]
        [SerializeField] private bool stopDedicatedRuntimeBeforeQuit = true;
        [SerializeField] private float dedicatedShutdownTimeoutSeconds = 2.5f;
        [SerializeField] private DedicatedServerRuntime dedicatedServerRuntime;
        [SerializeField] private GameServerControlDedicatedClient dedicatedControlClient;

        [Header("Role Guard")]
        [SerializeField] private DedicatedRuntimeRoleSwitcher roleSwitcher;
        [SerializeField] private bool skipDedicatedShutdownWhenRoleSwitcherIsClientOnly = true;

        [Header("Native Shutdown")]
        [SerializeField] private float grpcShutdownTimeoutSeconds = 2.5f;
        [SerializeField] private float logFlushDelaySeconds = 0.5f;
        [SerializeField] private float forceExitDelaySeconds = 2.0f;
        [SerializeField] private bool forceExitOnWindowsBuild = true;
        [SerializeField] private bool logExitFlow = true;

        private bool isQuitting;

        //* Binds the exit button when the object wakes up.
        private void Awake()
        {
                if (btnExit == null) btnExit = GetComponent<Button>();

                if (btnExit != null)
                {
                        btnExit.onClick.RemoveListener(ExitGame);
                        btnExit.onClick.AddListener(ExitGame);
                }
        }

        //* Starts safe exit flow for editor and Windows build.
        public void ExitGame()
        {
                if (isQuitting) return;

                isQuitting = true;

                if (btnExit != null) btnExit.interactable = false;

                Log("Exit requested.");
                StartCoroutine(QuitRoutine());
        }

        //* Shuts down dedicated runtime, native resources, logger flush window, then quits.
        private IEnumerator QuitRoutine()
        {
                Log("Quit routine started.");

                yield return WaitForDedicatedShutdown();

#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
                yield return WaitForGrpcShutdown();
#else
                yield return null;
#endif

                if (logFlushDelaySeconds > 0f)
                {
                        Log("Waiting for log flush before quit.");
                        yield return new WaitForSecondsRealtime(logFlushDelaySeconds);
                }

#if UNITY_EDITOR
                Log("Editor play mode stop called.");
                EditorApplication.isPlaying = false;
#else
#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
                ScheduleForceExitFallback();
#endif
                Log("Application.Quit called.");
                Application.Quit();
#endif
        }

        //* Waits for dedicated server offline heartbeat before runtime is stopped.
        private IEnumerator WaitForDedicatedShutdown()
        {
                if (!stopDedicatedRuntimeBeforeQuit) yield break;

                EnsureDedicatedReferences();

                if (!IsDedicatedShutdownAllowed())
                {
                        Log("Dedicated shutdown skipped because runtime role is ClientOnly.");
                        yield break;
                }

                bool hasRuntime = dedicatedServerRuntime != null && dedicatedServerRuntime.IsRunning;
                bool hasControl = dedicatedControlClient != null;

                if (!hasRuntime && !hasControl)
                {
                        Log("Dedicated shutdown skipped. runtime/control not found.");
                        yield break;
                }

                if (hasControl)
                {
                        bool offlineFinished = false;
                        bool offlineResult = false;

                        try
                        {
                                Task<bool> offlineTask = dedicatedControlClient.SendOfflineHeartbeatAsync();

                                if (offlineTask == null)
                                {
                                        offlineFinished = true;
                                }
                                else
                                {
                                        offlineTask.ContinueWith(task =>
                                        {
                                                offlineFinished = true;
                                                offlineResult = task.Status == TaskStatus.RanToCompletion && task.Result;
                                        });
                                }
                        }
                        catch (Exception ex)
                        {
                                offlineFinished = true;
                                Log("Dedicated offline heartbeat exception: " + ex.Message);
                        }

                        float timer = 0f;

                        while (!offlineFinished && timer < dedicatedShutdownTimeoutSeconds)
                        {
                                timer += Time.unscaledDeltaTime;
                                yield return null;
                        }

                        Log("Dedicated offline heartbeat finished or timed out. finished=" + offlineFinished + " result=" + offlineResult);
                }

                if (dedicatedServerRuntime != null && dedicatedServerRuntime.IsRunning)
                {
                        dedicatedServerRuntime.StopDedicatedRuntime();
                        Log("Dedicated runtime stop requested.");
                }
        }

        private bool IsDedicatedShutdownAllowed()
        {
                if (!skipDedicatedShutdownWhenRoleSwitcherIsClientOnly) return true;
                if (roleSwitcher == null) return true;
                return roleSwitcher.IsServerRoleAllowed;
        }

        //* Finds dedicated runtime and control client without creating new objects.
        private void EnsureDedicatedReferences()
        {
                if (roleSwitcher == null) roleSwitcher = FindObjectOfType<DedicatedRuntimeRoleSwitcher>(true);

                if (dedicatedServerRuntime == null) dedicatedServerRuntime = DedicatedServerRuntime.Instance;

                if (dedicatedServerRuntime == null)
                {
                        dedicatedServerRuntime = FindObjectOfType<DedicatedServerRuntime>(true);
                }

                if (dedicatedControlClient == null && dedicatedServerRuntime != null)
                {
                        dedicatedControlClient = dedicatedServerRuntime.GetComponent<GameServerControlDedicatedClient>();
                        if (dedicatedControlClient == null) dedicatedControlClient = dedicatedServerRuntime.GetComponentInChildren<GameServerControlDedicatedClient>(true);
                        if (dedicatedControlClient == null) dedicatedControlClient = dedicatedServerRuntime.GetComponentInParent<GameServerControlDedicatedClient>(true);
                }

                if (dedicatedControlClient == null)
                {
                        dedicatedControlClient = FindObjectOfType<GameServerControlDedicatedClient>(true);
                }
        }

#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
        //* Waits for native gRPC shutdown for a limited time.
        private IEnumerator WaitForGrpcShutdown()
        {
                bool shutdownFinished = false;

                try
                {
                        Task shutdownTask = GrpcNativeUnaryClient.ShutdownAsync();

                        if (shutdownTask == null)
                        {
                                shutdownFinished = true;
                        }
                        else
                        {
                                shutdownTask.ContinueWith(_ => shutdownFinished = true);
                        }
                }
                catch (Exception ex)
                {
                        shutdownFinished = true;
                        Log("Grpc shutdown exception: " + ex.Message);
                }

                float timer = 0f;

                while (!shutdownFinished && timer < grpcShutdownTimeoutSeconds)
                {
                        timer += Time.unscaledDeltaTime;
                        yield return null;
                }

                Log("Grpc shutdown finished or timed out. finished=" + shutdownFinished);
        }

        //* Starts a delayed force-exit fallback without killing the logger immediately.
        private void ScheduleForceExitFallback()
        {
                if (!forceExitOnWindowsBuild) return;

                int delayMs = Mathf.RoundToInt(Mathf.Max(0.5f, forceExitDelaySeconds) * 1000f);

                Task.Run(async () =>
                {
                        try
                        {
                                await Task.Delay(delayMs);
                                Environment.Exit(0);
                        }
                        catch
                        {
                        }
                });

                Log("Force exit fallback scheduled. delayMs=" + delayMs);
        }
#endif

        //* Removes button listener when object is destroyed.
        private void OnDestroy()
        {
                if (btnExit != null) btnExit.onClick.RemoveListener(ExitGame);
        }

        //* Prints exit logs to Unity console and project log file.
        private void Log(string message)
        {
                if (!logExitFlow) return;

                Debug.Log("[ExitGameButton] " + message);
        }
}
